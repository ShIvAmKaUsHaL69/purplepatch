(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_f3946a88._.js",
  "static/chunks/node_modules_gsap_27523451._.js",
  "static/chunks/node_modules_motion-dom_dist_es_2453d03e._.js",
  "static/chunks/node_modules_framer-motion_dist_es_83eff5f6._.js",
  "static/chunks/node_modules_next_944ebb86._.js",
  "static/chunks/node_modules_6b1180d4._.js"
],
    source: "dynamic"
});
