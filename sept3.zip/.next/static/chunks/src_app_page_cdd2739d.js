(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_a870c10a._.js",
  "static/chunks/node_modules_motion-dom_dist_es_2453d03e._.js",
  "static/chunks/node_modules_framer-motion_dist_es_83eff5f6._.js",
  "static/chunks/node_modules_gsap_27523451._.js",
  "static/chunks/node_modules_ef0f73ea._.js",
  "static/chunks/src_components_96717a37._.js"
],
    source: "dynamic"
});
